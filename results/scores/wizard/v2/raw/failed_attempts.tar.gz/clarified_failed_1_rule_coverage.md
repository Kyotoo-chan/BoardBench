# Rule coverage

Implementation scope is the packet's base game (not the listed variants).

| Packet rule | Implementation |
|---|---|
| 3–6 players; 60 cards | `new_game`, `make_deck` |
| Four coloured suits, values 1–13; four Wizards and four Jesters | `make_deck` |
| Round *r* deals *r* cards to every player | `start_round` |
| Undealt cards form a face-down stack; its top card determines trump | `start_round` |
| Jester indicator means no trump; Wizard lets dealer choose | `start_round`, `legal_actions` |
| No indicator/trump in the final round | `start_round` |
| Dealer rotates clockwise; player to dealer's left bids and leads | `start_round`, `apply_action` |
| Each bid is from zero through the number of tricks in the round | `legal_actions` |
| Follow the first ordinary led suit when possible | `led_suit`, `legal_card_indices` |
| Wizards and Jesters may always be played | `legal_card_indices` |
| First Wizard wins; otherwise highest trump, otherwise highest led suit | `trick_winner` |
| Leading Wizard fixes the winner and permits any following card | `led_suit`, `trick_winner` |
| Leading Jester does not set suit until an ordinary card is played | `led_suit` |
| All-Jester trick is won by the first Jester | `trick_winner` |
| Trick winner leads the next trick | `apply_action` |
| Exact bid: 20 plus 10 per trick; miss: −10 per trick of error | `_score_round` |
| Game ends after all cards are dealt; highest score wins | `apply_action`, `winners` |

Public API: `make_deck`, `new_game`/`setup_game`, `start_round`,
`legal_actions`/`get_legal_actions`, `legal_card_indices`, `apply_action`/`step`,
`led_suit`, `trick_winner`, `is_terminal`, and `winners`.
