"""Deterministic rules engine for the base game described in the supplied packet.

Cards use ``{"suit": "blue|green|red|yellow|wizard|jester",
"value": 1..13 or None}``.  State and actions are ordinary dictionaries so the
module can be used without framework-specific classes.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Iterable

SUITS = ("blue", "green", "red", "yellow")
WIZARD = "wizard"
JESTER = "jester"


def make_deck() -> list[dict[str, Any]]:
    """Return the complete 60-card deck in a stable order."""
    deck = [{"suit": suit, "value": value} for suit in SUITS for value in range(1, 14)]
    deck.extend({"suit": WIZARD, "value": None} for _ in range(4))
    deck.extend({"suit": JESTER, "value": None} for _ in range(4))
    return deck


def new_game(player_count: int, deck: Iterable[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Create a game state.

    ``deck`` is optional and its first element is dealt first.  Supplying it is
    useful for deterministic tests; shuffling is intentionally left to callers.
    """
    if not 3 <= player_count <= 6:
        raise ValueError("player_count must be between 3 and 6")
    cards = deepcopy(list(deck) if deck is not None else make_deck())
    if len(cards) != 60:
        raise ValueError("deck must contain exactly 60 cards")
    state = {
        "player_count": player_count,
        "round": 1,
        "dealer": 0,
        "scores": [0] * player_count,
        "deck": cards,
        "hands": [[] for _ in range(player_count)],
        "trump_card": None,
        "trump_suit": None,
        "bids": [None] * player_count,
        "tricks_won": [0] * player_count,
        "trick": [],
        "leader": 1 % player_count,
        "current_player": 1 % player_count,
        "phase": "deal",
    }
    return start_round(state)


def start_round(state: dict[str, Any]) -> dict[str, Any]:
    """Deal the current round and establish trump."""
    state = deepcopy(state)
    n, round_no = state["player_count"], state["round"]
    needed = n * round_no
    if len(state["deck"]) < needed:
        raise ValueError("not enough cards for this round")
    state["hands"] = [[] for _ in range(n)]
    for _ in range(round_no):
        for player in range(n):
            state["hands"][player].append(state["deck"].pop(0))
    state["trump_card"] = state["deck"].pop(0) if state["deck"] else None
    card = state["trump_card"]
    state["trump_suit"] = card["suit"] if card and card["suit"] in SUITS else None
    state["bids"] = [None] * n
    state["tricks_won"] = [0] * n
    state["trick"] = []
    state["leader"] = (state["dealer"] + 1) % n
    state["phase"] = "choose_trump" if card and card["suit"] == WIZARD else "bidding"
    state["current_player"] = state["dealer"] if state["phase"] == "choose_trump" else state["leader"]
    return state


def legal_actions(state: dict[str, Any]) -> list[dict[str, Any]]:
    """Return all legal actions for the current player."""
    phase = state["phase"]
    player = state["current_player"]
    if phase == "choose_trump":
        return [{"type": "choose_trump", "suit": suit} for suit in SUITS]
    if phase == "bidding":
        return [{"type": "bid", "value": value} for value in range(state["round"] + 1)]
    if phase == "playing":
        indices = legal_card_indices(state["hands"][player], state["trick"])
        return [{"type": "play", "card_index": i} for i in indices]
    if phase == "round_end":
        return [{"type": "next_round"}]
    return []


def legal_card_indices(hand: list[dict[str, Any]], trick: list[dict[str, Any]]) -> list[int]:
    """Return playable hand indices, applying follow-suit and special-card rules."""
    led = led_suit(trick)
    if led is None:
        return list(range(len(hand)))
    matching = [i for i, card in enumerate(hand) if card["suit"] == led]
    if not matching:
        return list(range(len(hand)))
    specials = [i for i, card in enumerate(hand) if card["suit"] in (WIZARD, JESTER)]
    return matching + specials


def apply_action(state: dict[str, Any], action: dict[str, Any]) -> dict[str, Any]:
    """Validate and apply one action, returning a new state."""
    if action not in legal_actions(state):
        raise ValueError("illegal action")
    state = deepcopy(state)
    n, player = state["player_count"], state["current_player"]
    if action["type"] == "choose_trump":
        state["trump_suit"] = action["suit"]
        state["phase"] = "bidding"
        state["current_player"] = state["leader"]
    elif action["type"] == "bid":
        state["bids"][player] = action["value"]
        nxt = (player + 1) % n
        if state["bids"][nxt] is None:
            state["current_player"] = nxt
        else:
            state["phase"] = "playing"
            state["current_player"] = state["leader"]
    elif action["type"] == "play":
        card = state["hands"][player].pop(action["card_index"])
        state["trick"].append({"player": player, "card": card})
        if len(state["trick"]) < n:
            state["current_player"] = (player + 1) % n
        else:
            winner = trick_winner(state["trick"], state["trump_suit"])
            state["tricks_won"][winner] += 1
            state["trick"] = []
            state["leader"] = winner
            state["current_player"] = winner
            if not any(state["hands"]):
                _score_round(state)
                state["phase"] = "game_over" if not state["deck"] else "round_end"
    else:
        state["round"] += 1
        state["dealer"] = (state["dealer"] + 1) % n
        return start_round(state)
    return state


def led_suit(trick: list[dict[str, Any]]) -> str | None:
    """The first ordinary suit played; leading jesters do not establish suit."""
    for play in trick:
        suit = play["card"]["suit"]
        if suit == WIZARD:
            return None
        if suit in SUITS:
            return suit
    return None


def trick_winner(trick: list[dict[str, Any]], trump_suit: str | None) -> int:
    """Return the player id winning a complete or partial trick."""
    if not trick:
        raise ValueError("trick must not be empty")
    for play in trick:
        if play["card"]["suit"] == WIZARD:
            return play["player"]
    ordinary = [play for play in trick if play["card"]["suit"] in SUITS]
    if not ordinary:  # all jesters: the first wins
        return trick[0]["player"]
    trumps = [play for play in ordinary if play["card"]["suit"] == trump_suit]
    candidates = trumps or [play for play in ordinary if play["card"]["suit"] == led_suit(trick)]
    return max(candidates, key=lambda play: play["card"]["value"])["player"]


def _score_round(state: dict[str, Any]) -> None:
    for player, (bid, won) in enumerate(zip(state["bids"], state["tricks_won"])):
        state["scores"][player] += 20 + 10 * won if bid == won else -10 * abs(bid - won)


# Small compatibility aliases forming an explicit public contract.
setup_game = new_game
get_legal_actions = legal_actions
step = apply_action


def is_terminal(state: dict[str, Any]) -> bool:
    return state["phase"] == "game_over"


def winners(state: dict[str, Any]) -> list[int]:
    if not is_terminal(state):
        return []
    best = max(state["scores"])
    return [i for i, score in enumerate(state["scores"]) if score == best]
