## Assessment

**Score: 0.88 — confidence: high.**

The implementation correctly covers nearly all base-game rules: inventory, supported player counts, dealing, dealer rotation, trump branches, bidding, ordinary follow-suit, special-card priority, scoring, final-round timing, and cumulative returns. Two material deviations remain: the approved Jester→Wizard ruling is implemented incorrectly, and public observations discard completed-trick card information.

## Findings

### Major — Jester followed by Wizard incorrectly permits a later led suit

- **Canonical fact:** `WIZ-G-JESTER-WIZARD` / `WIZ-DEC-JESTER`
- **Evidence type:** `human_decision`
- **Source:** `WIZARD-V2-RULEFACTS`
- **Locator:** `canonical_rulefacts.md`, “Material source gaps and proposed clarification decisions,” item 6; corresponding gap at `canonical_claims.json#/claims/56`
- **Exact evidence:** “a Wizard before that card keeps the trick colorless, allows all later cards, and the first Wizard wins.”
- **Conflicting code:** `Game.apply_action`, particularly `if trick[0]["card"] != "zauberer" and data["led_suit"] is None` at implementation line 197; subsequently enforced by `Game.legal_actions`.
- **Expected:** After Jester→Wizard, the trick remains colorless for its entire duration. Every later card is legal, even after an ordinary card appears, and the first Wizard wins.
- **Implemented:** Because the first card is a Jester rather than a Wizard, the first later ordinary card sets `led_suit`. Subsequent players holding that suit are then restricted to that suit or a special card.
- **Impact:** Materially changes legal actions in an approved edge case. Trick winner remains the Wizard, but players can be forced to play cards they were entitled to retain.
- **Provenance:** This is an adjudication-dependent deviation from the approved human decision, not a contradiction of an independently complete printed rule.

### Major — Completed played cards cease to be public in observations

- **Canonical fact:** `WIZ-G-PRIVACY` / `WIZ-DEC-PRIVACY`
- **Evidence type:** `human_decision`
- **Source:** `WIZARD-V2-RULEFACTS`
- **Locator:** `canonical_rulefacts.md`, “Material source gaps and proposed clarification decisions,” item 8; corresponding gap at `canonical_claims.json#/claims/58`
- **Exact evidence:** “each player observes their own cards and opponents’ hand sizes; predictions, revealed trump, and played cards are public.”
- **Conflicting code:** `Game.observation_to_data`, especially `completed_trick_count` at implementation line 395.
- **Expected:** All players’ observations retain the identities of played cards, including cards in completed tricks, while opponents’ unplayed hands remain private.
- **Implemented:** The current trick is exposed, but completed tricks are reduced to a count. Their card identities are retained only in the private full state.
- **Impact:** Removes material public history and can prevent players from tracking which cards have already appeared.
- **Provenance:** This follows the approved privacy decision; the printed rulebook alone does not define a machine-readable information boundary.

No critical or minor findings identified.

## Rule-area coverage

| Rule area | Result | Notes |
|---|---|---|
| Scope and inventory | Pass | Base game only; 52 ordinary cards, four Wizards, four Jesters |
| Player setup | Pass | Supports exactly 3–6; player 0 is initial dealer |
| Deal/reset/chance | Pass | Fresh 60-card shuffle each round; round number equals hand size |
| Trump determination | Pass | Ordinary, Jester, Wizard-choice, and final-round branches |
| Predictions | Pass | Required, bounded, clockwise from dealer-left, unrestricted sum |
| Turn order | Pass | Correct first leader, clockwise play, winner leads next |
| Follow-suit legality | Partial | Ordinary and direct Wizard-led cases pass; Jester→Wizard fails |
| Trick winner | Pass | First Wizard, highest trump, highest led suit, all-Jester priority |
| Scoring | Pass | Exact bonus and ±10-per-trick difference |
| Round/game end | Pass | Correct 20/15/12/10 rounds and final scoring before termination |
| Returns/ties | Pass | Raw final score vector preserves equal-high-score ties |
| Private/public information | Partial | Hands protected, but completed played-card history is hidden |
| Serialization validation | Question | Round-trip works, but imported-state invariants are only partially checked |

## Missing deterministic scenarios

Additional deterministic coverage should include:

1. Lead Jester, then Wizard, then an ordinary card; verify every remaining card in the next player’s hand is legal, including off-suit ordinary cards.
2. The same sequence with multiple leading Jesters before the Wizard.
3. Complete a trick, then verify every player observation exposes all completed card identities while exposing no opponent hand contents.
4. Complete several tricks and verify public played-card history remains available across trick boundaries.
5. End with tied highest scores and verify consumers treat every tied leader as a joint winner.
6. If deserialized payloads are intended to be adversarially validated, cover inconsistent round limits, out-of-range current players, impossible card multiplicities, and phase/terminal mismatches.

## Material questions for a human

- Does the module contract require `returns()` to expose raw cumulative scores, as implemented, or normalized winner utilities? The approved rules determine the highest-score winner but do not define API return encoding.
- Must `state_from_data` reject every unreachable or inventory-inconsistent state, or is it only required to load trusted output from `state_to_data`? This is interface policy rather than a publisher-rule question.

```text
score: 0.88
confidence: high
critical_issues: 0
major_issues: 2
minor_issues: 0
needs_rulebook_clarification: false
needs_code_change: true
needs_more_tests: true
```