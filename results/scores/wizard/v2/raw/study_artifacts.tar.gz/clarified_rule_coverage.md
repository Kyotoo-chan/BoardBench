# Rule coverage

Only the supplied German Version 1.0 rulebook is used as behavioral evidence. `ENVIRONMENT_CONTRACT.md` and `GAME_PROFILE.json` supply representation requirements only.

| Source section / named rule | Implementing symbol(s) | Probe or reason not probed | Assumption |
|---|---|---|---|
| Das Spiel, das Sie in Rage bringt (3–6 players; 60 cards) | `Game.__init__`, `_deck` | Constructor/deck inventory exercised by canonical fixture checks | None |
| Es war einmal … | None (theme only) | No game behavior to probe | None |
| Die Aufgabe | `Game._finish_round`, `Game.is_terminal`, `Game.returns` | Full rollouts in `agentic_self_check.py` | Return convention A-02 |
| Die Vorbereitung | `Game.initial_state`, `_deal_round` | Initial-state canonical and rollout probes | Initial Vertrauter/dealer A-01 |
| Die Charakterkarten: four colors, ranks 1–13, four Zauberer, four Narren | `SUITS`, `_deck`, `_ordinary`, `_valid_card` | Canonical inventory and action round trips | None |
| Zauberer always trump and above 13; Narr never trump and below 1 | `_trick_winner` | Full rollouts plus source-only direct fixture reasoning | None |
| Das Verteilen der Karten: round N deals N cards; undealt stack; dealing duty rotates | `_deal_round`, `_finish_round` | Rollouts cross round boundaries | Initial dealer A-01 |
| Der Trumpf: reveal top stack card | `_deal_round` | Seeded initial states and rollouts | None |
| Revealed Narr means no trump | `_deal_round` | Source-only branch inspection; shuffle may or may not reach it in bounded check | None |
| Revealed Zauberer lets dealer choose one of four trump colors | `_deal_round`, `legal_actions`, `apply_action` (`choose_trump`) | Legal-action and successor probes | None |
| Final round has no stack and no trump | `_deal_round` | Full game may exceed bounded generic rollout; source-only boundary inspection | None |
| Die Vorhersage: starts left of dealer; predictions recorded openly | `_deal_round`, `legal_actions`, `apply_action` (`predict`), `observation_to_data` | Rollout legal-action probes and observation round trips | None |
| Der Kampf um den Stich: left of dealer leads first trick; winner leads next | `_deal_round`, `apply_action` (`play_card`) | Rollout successor probes | None |
| Must follow led color if possible; otherwise discard or trump | `legal_actions` | Every legal action accepted in self-check | None |
| Zauberer and Narr may always be played | `legal_actions` | Every legal action accepted in self-check | None |
| Highest card wins; trump outranks other colors | `_trick_winner` | Source-only direct fixture reasoning and rollouts | None |
| First round consists of one trick | `_deal_round` (one card each) | Initial rollout | None |
| Winner order: first Zauberer, else highest trump, else highest led color | `_trick_winner` | Source-only direct fixture reasoning and rollouts | None |
| Spezielle Rechte: Zauberer lead permits any following cards and first Zauberer wins | `legal_actions`, `apply_action`, `_trick_winner` | Source-only branch inspection | None |
| Zauberer need not be played to follow trump | `legal_actions` | Source-only branch inspection | None |
| Narr lead: second card arbitrary; first ordinary card establishes color | `apply_action`, `legal_actions` | Source-only branch inspection | None |
| Narren lose every trick; all-Narr trick won by first Narr | `_trick_winner` | Source-only direct fixture reasoning | None |
| Scoring: exact prediction earns 20 + 10 per won trick | `_finish_round` | Rollouts cross scoring boundaries | None |
| Scoring: miss loses 10 per trick above/below prediction | `_finish_round` | Rollouts cross scoring boundaries | None |
| Scoring example (Thomas/Ute/Kevin) | `_finish_round` | Arithmetic represented directly; named example not separately executed | None |
| Das Ende: 60 cards; final round 10/12/15/20 for 6/5/4/3 players | `max_round = 60 // n`, `_finish_round` | 3/4/5/6 player fixture probes | None |
| Winner has highest experience points | terminal `returns` expose final scores | Result ordering is available from returned scores; no extra winner field in profile | A-02 |
| Varianten: Plus/minus Eins | Not implemented (base variant only) | Profile fixes `configuration.variant` to `base` | None |
| Varianten: Verdeckter Tipp | Not implemented (base variant only) | Profile fixes `configuration.variant` to `base` | None |
| Varianten: Geheime Vorhersage | Not implemented (base variant only) | Profile fixes `configuration.variant` to `base` | None |
| Varianten: Hellsehen | Not implemented (base variant only) | Profile fixes `configuration.variant` to `base` | None |
| Varianten: Einfarbig (3 or 4 players) | Not implemented (base variant only) | Profile fixes `configuration.variant` to `base` | None |
| Canonical complete state/action reconstruction | `state_to_data`, `state_from_data`, `action_to_data`, `action_from_data` | `agentic_self_check.py`, `profile_fixture_self_check.py` | Representation only |
| Private hands / public play information | `observation_to_data` | Observation envelope/field checks; other hands represented only by size | None |
| Seeded chance | `_deal_round`, `chance.shuffle_index` | Repeated seeded construction and serialized-state round trips | None |
