# Attempt 1

1. Material assumptions:

- Player 0 is the initial dealer; dealing rotates clockwise.
- Nonterminal returns are zero; terminal returns are final scores.

2. Files changed:

- `implementation.py`
- `rule_coverage.md`
- `assumptions.json`

3. Validation:

- `python -m py_compile implementation.py` — passed
- `python agentic_self_check.py` — `agentic-self-check OK states=300 actions=1101`
- `python profile_fixture_self_check.py` — `profile-fixture-self-check OK`
