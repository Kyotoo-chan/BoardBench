## 1. Score

**score: 0.91 — confidence: high**

The module correctly implements nearly all approved base-game rules: inventory, dealing, trump selection, bidding, ordinary follow-suit, direct Wizard leads, trick resolution, scoring, round rotation, final-round handling, and score returns. One adjudication-dependent special-card sequence materially restricts legal play incorrectly.

Source and rendered-page hashes match their manifests.

## 2. Findings

### Major — Jester→Wizard does not remain colorless

- **Canonical fact ID:** `WIZ-G-JESTER-WIZARD` / `WIZ-DEC-JESTER`
- **Evidence type:** `human_decision`
- **Source:** `WIZARD-V2-RULEFACTS`
- **Locator:** `canonical_rulefacts.md`, “Material source gaps and proposed clarification decisions,” item 6
- **Exact evidence:** “leading Jesters remain colorless until the first ordinary card; a Wizard before that card keeps the trick colorless, allows all later cards, and the first Wizard wins.”
- **Conflicting symbols:** `Game.apply_action`, particularly the `led_suit` transition at lines 197–200; subsequently enforced by `Game.legal_actions` at lines 164–169.
- **Expected:** After `Jester → Wizard`, the trick remains colorless for its entire duration. Every later card remains legal, and the first Wizard wins.
- **Implemented:** Because the first card is not a Wizard, a later ordinary card sets `led_suit`. Any still-later player holding that suit is then prohibited from playing an off-suit ordinary card.
- **Impact:** In games with enough remaining followers, legal actions are materially narrower than the approved decision allows. First-Wizard winner resolution itself remains correct.
- **Provenance distinction:** This is based on an approved human gap resolution, not an independently clear printed rule. Direct Wizard-led tricks correctly remain unrestricted under `WIZ-C-WIZARD-LEAD-FREE`.

### Question — persistence of public played-card information

`WIZ-G-PRIVACY` / `WIZ-DEC-PRIVACY` says “predictions, revealed trump, and played cards are public.” `observation_to_data` exposes the current trick but only a count for completed tricks.

Whether this is deficient depends on the surrounding contract: if players receive and retain the public action history, the observation is sufficient; if each observation must be self-contained, completed played cards should also be exposed. The supplied rule packet does not settle that interface-level distinction.

## 3. Rule-area coverage

| Rule area | Result | Notes |
|---|---|---|
| Scope and player counts | Pass | Base variant; 3–6 players |
| Inventory and ranks | Pass | 52 ordinary cards, four Wizards, four Jesters |
| Dealer and dealing | Pass | Correct round-sized hands, reshuffle, clockwise rotation |
| Trump determination | Pass | Ordinary, Jester, Wizard-choice, and final-round branches |
| Predictions | Pass | Required, sequential, dealer-left first, range `0..hand size` |
| Ordinary follow-suit | Pass | Specials remain legal; void players unrestricted |
| Wizard-led trick | Pass | No suit obligation arises |
| Jester-led trick | **Major** | `Jester → Wizard → ordinary` incorrectly creates a led suit |
| Trick winner/leadership | Pass | First Wizard, highest trump/led card, all-Jester priority |
| Scoring | Pass | Exact bonus and over/under penalties accumulate correctly |
| Terminal conditions | Pass | Correct 20/15/12/10 rounds and final-round scoring |
| Returns/ties | Pass | Score vector preserves equal highest scores as joint maxima |
| Private/public information | Question | Completed public cards omitted from observation snapshot |

## 4. Needed deterministic scenarios

- Four-player sequence `Jester → Wizard → ordinary → follower`, where the follower holds both the ordinary card’s suit and an off-suit card; assert both are legal and `led_suit` remains `None`.
- The same sequence with an ordinary trump card afterward; assert the first Wizard still wins and leads the next trick.
- Observation immediately after completing a trick, specifying whether every completed card must remain present or public action history is supplied separately.
- Terminal equal-score case confirming that consumers interpret equal maximum returns as joint winners.

## 5. Material question for a human

Must a serialized observation be self-contained with respect to every previously played public card, or may clients rely on retained public action history? This determines whether omission of `completed_tricks` from observations requires a code change.

```text
score: 0.91
confidence: high
critical_issues: 0
major_issues: 1
minor_issues: 0
needs_rulebook_clarification: true
needs_code_change: true
needs_more_tests: true
```