"""Self-contained implementation of Wizard (German rulebook, Version 1.0)."""

from __future__ import annotations

import copy
import random


SUITS = ("menschen_blau", "elfen_gruen", "zwerge_rot", "riesen_gelb")
SUIT_LABELS = {
    "menschen_blau": "Menschen (blau)",
    "elfen_gruen": "Elfen (grün)",
    "zwerge_rot": "Zwerge (rot)",
    "riesen_gelb": "Riesen (gelb)",
}
SPECIALS = ("zauberer", "narr")
PHASES = ("choose_trump", "predict", "play", "terminal")
STATE_SCHEMA = "boardbench/wizard/state/1"
ACTION_SCHEMA = "boardbench/wizard/action/1"
OBSERVATION_SCHEMA = "boardbench/wizard/observation/1"


class Action:
    def __init__(self, type_, actor, value):
        self.type = type_
        self.actor = actor
        self.value = value

    def __eq__(self, other):
        return (
            isinstance(other, Action)
            and (self.type, self.actor, self.value)
            == (other.type, other.actor, other.value)
        )

    def __hash__(self):
        return hash((self.type, self.actor, self.value))


class GameState:
    """Mutable-free-by-convention complete evaluator state."""

    def __init__(self, data):
        self.data = data


def _deck():
    cards = [f"{suit}:{rank}" for suit in SUITS for rank in range(1, 14)]
    return cards + ["zauberer"] * 4 + ["narr"] * 4


def _ordinary(card):
    if card in SPECIALS:
        return None
    suit, rank = card.rsplit(":", 1)
    return suit, int(rank)


def _is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _exact_dict(value, keys, where):
    if not isinstance(value, dict) or set(value) != set(keys):
        raise ValueError(f"{where} must contain exactly {sorted(keys)}")


class Game:
    def __init__(self, num_players=None, seed=None):
        if num_players is None:
            num_players = 4
        if num_players not in (3, 4, 5, 6):
            raise ValueError("num_players must be one of 3, 4, 5, 6")
        if seed is not None and not _is_int(seed):
            raise ValueError("seed must be an integer or None")
        self.num_players = num_players
        self.seed = seed

    def initial_state(self):
        n = self.num_players
        data = {
            "configuration": {"players": n, "seed": self.seed, "variant": "base"},
            "round_number": 1,
            "max_round": 60 // n,
            "dealer": 0,
            "leader": 1 % n,
            "current_player": 1 % n,
            "phase": "predict",
            "terminal": False,
            "trump_suit": None,
            "led_suit": None,
            "players": [
                {"id": i, "hand": [], "prediction": None, "tricks_won": 0, "score": 0}
                for i in range(n)
            ],
            "zones": {
                "deck": [],
                "revealed_trump": None,
                "trick": [],
                "completed_tricks": [],
                "reserve": [],
            },
            "pending": None,
            "chance": {"seed": self.seed, "shuffle_index": 0},
        }
        self._deal_round(data)
        return GameState(data)

    def _deal_round(self, data):
        n = data["configuration"]["players"]
        round_number = data["round_number"]
        cards = _deck()
        base_seed = data["chance"]["seed"]
        random.Random((0 if base_seed is None else base_seed) + 1000003 * data["chance"]["shuffle_index"]).shuffle(cards)
        data["chance"]["shuffle_index"] += 1
        for player in data["players"]:
            player["hand"] = []
            player["prediction"] = None
            player["tricks_won"] = 0
        for _ in range(round_number):
            for player in data["players"]:
                player["hand"].append(cards.pop())
        data["zones"] = {
            "deck": cards,
            "revealed_trump": None,
            "trick": [],
            "completed_tricks": [],
            "reserve": [],
        }
        data["trump_suit"] = None
        data["led_suit"] = None
        data["leader"] = (data["dealer"] + 1) % n
        if cards:
            revealed = cards.pop()
            data["zones"]["revealed_trump"] = revealed
            if revealed == "zauberer":
                data["phase"] = "choose_trump"
                data["current_player"] = data["dealer"]
                data["pending"] = {"type": "trump_choice", "player": data["dealer"]}
                return
            ordinary = _ordinary(revealed)
            if ordinary:
                data["trump_suit"] = ordinary[0]
        data["phase"] = "predict"
        data["current_player"] = data["leader"]
        data["pending"] = None

    def current_player(self, state):
        return state.data["current_player"]

    def legal_actions(self, state):
        data = state.data
        if data["terminal"] or data["phase"] == "terminal":
            return []
        actor = data["current_player"]
        if data["phase"] == "choose_trump":
            return [Action("choose_trump", actor, suit) for suit in SUITS]
        if data["phase"] == "predict":
            return [Action("predict", actor, tricks) for tricks in range(data["round_number"] + 1)]
        if data["phase"] != "play":
            return []
        hand = data["players"][actor]["hand"]
        unique = list(dict.fromkeys(hand))
        led = data["led_suit"]
        if led and any(_ordinary(card) and _ordinary(card)[0] == led for card in hand):
            unique = [
                card for card in unique
                if card in SPECIALS or (_ordinary(card) and _ordinary(card)[0] == led)
            ]
        return [Action("play_card", actor, card) for card in unique]

    def apply_action(self, state, action):
        legal = self.legal_actions(state)
        if action not in legal:
            raise ValueError("illegal action")
        data = copy.deepcopy(state.data)
        n = data["configuration"]["players"]
        actor = action.actor
        if action.type == "choose_trump":
            data["trump_suit"] = action.value
            data["pending"] = None
            data["phase"] = "predict"
            data["current_player"] = data["leader"]
        elif action.type == "predict":
            data["players"][actor]["prediction"] = action.value
            next_player = (actor + 1) % n
            if all(player["prediction"] is not None for player in data["players"]):
                data["phase"] = "play"
                data["current_player"] = data["leader"]
            else:
                data["current_player"] = next_player
        else:
            hand = data["players"][actor]["hand"]
            hand.remove(action.value)
            trick = data["zones"]["trick"]
            trick.append({"player": actor, "card": action.value})
            if trick[0]["card"] != "zauberer" and data["led_suit"] is None:
                ordinary = _ordinary(action.value)
                if ordinary:
                    data["led_suit"] = ordinary[0]
            if len(trick) < n:
                data["current_player"] = (actor + 1) % n
            else:
                winner = self._trick_winner(trick, data["trump_suit"], data["led_suit"])
                data["players"][winner]["tricks_won"] += 1
                data["zones"]["completed_tricks"].append({
                    "winner": winner,
                    "cards": [entry["card"] for entry in trick],
                })
                data["zones"]["trick"] = []
                data["led_suit"] = None
                data["leader"] = winner
                data["current_player"] = winner
                if not any(player["hand"] for player in data["players"]):
                    self._finish_round(data)
        return GameState(data)

    @staticmethod
    def _trick_winner(trick, trump, led):
        for entry in trick:
            if entry["card"] == "zauberer":
                return entry["player"]
        candidates = []
        if trump:
            candidates = [
                entry for entry in trick
                if _ordinary(entry["card"]) and _ordinary(entry["card"])[0] == trump
            ]
        if not candidates and led:
            candidates = [
                entry for entry in trick
                if _ordinary(entry["card"]) and _ordinary(entry["card"])[0] == led
            ]
        if candidates:
            return max(candidates, key=lambda entry: _ordinary(entry["card"])[1])["player"]
        return trick[0]["player"]

    def _finish_round(self, data):
        for player in data["players"]:
            difference = abs(player["prediction"] - player["tricks_won"])
            if difference == 0:
                player["score"] += 20 + 10 * player["tricks_won"]
            else:
                player["score"] -= 10 * difference
        if data["round_number"] >= data["max_round"]:
            data["phase"] = "terminal"
            data["terminal"] = True
            data["current_player"] = -1
            data["pending"] = None
            return
        data["round_number"] += 1
        data["dealer"] = (data["dealer"] + 1) % data["configuration"]["players"]
        self._deal_round(data)

    def is_terminal(self, state):
        return bool(state.data["terminal"])

    def returns(self, state):
        if not self.is_terminal(state):
            return [0] * state.data["configuration"]["players"]
        return [player["score"] for player in state.data["players"]]

    def render(self, state):
        data = state.data
        scores = ", ".join(f"S{p['id'] + 1}={p['score']}" for p in data["players"])
        return (
            f"Wizard | Runde {data['round_number']}/{data['max_round']} | "
            f"Phase {data['phase']} | Spieler {data['current_player']} | {scores}"
        )

    def action_to_name(self, action):
        prefix = f"Spieler {action.actor + 1} — "
        if action.type == "choose_trump":
            return prefix + "Trumpf wählen: " + SUIT_LABELS[action.value]
        if action.type == "predict":
            return prefix + f"Vorhersage: {action.value} Stich(e)"
        if action.value == "zauberer":
            label = "Zauberer"
        elif action.value == "narr":
            label = "Narr"
        else:
            suit, rank = _ordinary(action.value)
            label = f"{SUIT_LABELS[suit]} {rank}"
        return prefix + "Karte spielen: " + label

    def name_to_action(self, name):
        if not isinstance(name, str) or not name.startswith("Spieler ") or " — " not in name:
            raise ValueError("unknown action name")
        head, body = name.split(" — ", 1)
        try:
            actor = int(head[8:]) - 1
        except ValueError as exc:
            raise ValueError("unknown action name") from exc
        if actor < 0:
            raise ValueError("unknown action name")
        if body.startswith("Trumpf wählen: "):
            label = body[len("Trumpf wählen: "):]
            reverse = {value: key for key, value in SUIT_LABELS.items()}
            if label not in reverse:
                raise ValueError("unknown action name")
            return Action("choose_trump", actor, reverse[label])
        if body.startswith("Vorhersage: ") and body.endswith(" Stich(e)"):
            text = body[len("Vorhersage: "):-len(" Stich(e)")]
            if not text.isdigit():
                raise ValueError("unknown action name")
            return Action("predict", actor, int(text))
        if body.startswith("Karte spielen: "):
            label = body[len("Karte spielen: "):]
            if label == "Zauberer":
                return Action("play_card", actor, "zauberer")
            if label == "Narr":
                return Action("play_card", actor, "narr")
            for suit, suit_label in SUIT_LABELS.items():
                prefix_label = suit_label + " "
                if label.startswith(prefix_label) and label[len(prefix_label):].isdigit():
                    rank = int(label[len(prefix_label):])
                    if 1 <= rank <= 13:
                        return Action("play_card", actor, f"{suit}:{rank}")
        raise ValueError("unknown action name")

    def state_to_data(self, state):
        return {"schema": STATE_SCHEMA, "data": copy.deepcopy(state.data)}

    def state_from_data(self, payload):
        _exact_dict(payload, ("schema", "data"), "state envelope")
        if payload["schema"] != STATE_SCHEMA:
            raise ValueError("wrong state schema")
        data = copy.deepcopy(payload["data"])
        self._validate_state(data)
        return GameState(data)

    def action_to_data(self, action):
        if not isinstance(action, Action):
            raise ValueError("invalid action")
        key = {"choose_trump": "suit", "predict": "tricks", "play_card": "card"}.get(action.type)
        if key is None:
            raise ValueError("invalid action type")
        return {
            "schema": ACTION_SCHEMA,
            "data": {"type": action.type, "actor": action.actor, "args": {key: action.value}},
        }

    def action_from_data(self, payload):
        _exact_dict(payload, ("schema", "data"), "action envelope")
        if payload["schema"] != ACTION_SCHEMA:
            raise ValueError("wrong action schema")
        data = payload["data"]
        _exact_dict(data, ("type", "actor", "args"), "action data")
        if not _is_int(data["actor"]) or data["actor"] < 0:
            raise ValueError("invalid actor")
        specs = {
            "choose_trump": ("suit", lambda x: x in SUITS),
            "predict": ("tricks", lambda x: _is_int(x) and x >= 0),
            "play_card": ("card", self._valid_card),
        }
        if data["type"] not in specs:
            raise ValueError("invalid action type")
        key, validator = specs[data["type"]]
        _exact_dict(data["args"], (key,), "action args")
        value = data["args"][key]
        if not validator(value):
            raise ValueError("invalid action argument")
        return Action(data["type"], data["actor"], value)

    def observation_to_data(self, state, player):
        data = state.data
        n = data["configuration"]["players"]
        if not _is_int(player) or not 0 <= player < n:
            raise ValueError("invalid player")
        observed_players = [
            {
                "id": entry["id"],
                "hand_size": len(entry["hand"]),
                "prediction": entry["prediction"],
                "tricks_won": entry["tricks_won"],
                "score": entry["score"],
            }
            for entry in data["players"]
        ]
        result = {
            "player": player,
            "round_number": data["round_number"],
            "max_round": data["max_round"],
            "dealer": data["dealer"],
            "leader": data["leader"],
            "current_player": data["current_player"],
            "phase": data["phase"],
            "terminal": data["terminal"],
            "trump_suit": data["trump_suit"],
            "led_suit": data["led_suit"],
            "own_hand": list(data["players"][player]["hand"]),
            "players": observed_players,
            "revealed_trump": data["zones"]["revealed_trump"],
            "trick": copy.deepcopy(data["zones"]["trick"]),
            "completed_trick_count": len(data["zones"]["completed_tricks"]),
            "deck_size": len(data["zones"]["deck"]),
        }
        return {"schema": OBSERVATION_SCHEMA, "data": result}

    @staticmethod
    def _valid_card(card):
        if not isinstance(card, str):
            return False
        if card in SPECIALS:
            return True
        try:
            suit, rank = card.rsplit(":", 1)
            return suit in SUITS and rank.isdigit() and 1 <= int(rank) <= 13
        except ValueError:
            return False

    def _validate_state(self, data):
        required = (
            "configuration", "round_number", "max_round", "dealer", "leader",
            "current_player", "phase", "terminal", "trump_suit", "led_suit",
            "players", "zones", "pending", "chance",
        )
        _exact_dict(data, required, "state data")
        _exact_dict(data["configuration"], ("players", "seed", "variant"), "configuration")
        n = data["configuration"]["players"]
        if n not in (3, 4, 5, 6) or data["configuration"]["variant"] != "base":
            raise ValueError("invalid configuration")
        seed = data["configuration"]["seed"]
        if seed is not None and not _is_int(seed):
            raise ValueError("invalid configuration seed")
        integer_fields = ("round_number", "max_round", "dealer", "leader", "current_player")
        if any(not _is_int(data[key]) for key in integer_fields):
            raise ValueError("invalid integer state field")
        if data["phase"] not in PHASES or not isinstance(data["terminal"], bool):
            raise ValueError("invalid phase or terminal flag")
        if data["trump_suit"] is not None and data["trump_suit"] not in SUITS:
            raise ValueError("invalid trump suit")
        if data["led_suit"] is not None and data["led_suit"] not in SUITS:
            raise ValueError("invalid led suit")
        if not isinstance(data["players"], list) or len(data["players"]) != n:
            raise ValueError("invalid players")
        for entry in data["players"]:
            _exact_dict(entry, ("id", "hand", "prediction", "tricks_won", "score"), "player")
            if not all(_is_int(entry[key]) for key in ("id", "tricks_won", "score")):
                raise ValueError("invalid player integer")
            if entry["prediction"] is not None and not _is_int(entry["prediction"]):
                raise ValueError("invalid prediction")
            self._validate_cards(entry["hand"])
        if sorted(entry["id"] for entry in data["players"]) != list(range(n)):
            raise ValueError("invalid player ids")
        zones = data["zones"]
        _exact_dict(zones, ("deck", "revealed_trump", "trick", "completed_tricks", "reserve"), "zones")
        self._validate_cards(zones["deck"])
        self._validate_cards(zones["reserve"])
        if zones["revealed_trump"] is not None and not self._valid_card(zones["revealed_trump"]):
            raise ValueError("invalid revealed trump")
        if not isinstance(zones["trick"], list):
            raise ValueError("invalid trick")
        for entry in zones["trick"]:
            _exact_dict(entry, ("player", "card"), "trick entry")
            if not _is_int(entry["player"]) or not self._valid_card(entry["card"]):
                raise ValueError("invalid trick entry")
        if not isinstance(zones["completed_tricks"], list):
            raise ValueError("invalid completed tricks")
        for entry in zones["completed_tricks"]:
            _exact_dict(entry, ("winner", "cards"), "completed trick")
            if not _is_int(entry["winner"]):
                raise ValueError("invalid winner")
            self._validate_cards(entry["cards"])
        if data["pending"] is not None:
            _exact_dict(data["pending"], ("type", "player"), "pending")
            if data["pending"]["type"] != "trump_choice" or not _is_int(data["pending"]["player"]):
                raise ValueError("invalid pending decision")
        _exact_dict(data["chance"], ("seed", "shuffle_index"), "chance")
        if data["chance"]["seed"] is not None and not _is_int(data["chance"]["seed"]):
            raise ValueError("invalid chance seed")
        if not _is_int(data["chance"]["shuffle_index"]):
            raise ValueError("invalid shuffle index")

    def _validate_cards(self, cards):
        if not isinstance(cards, list) or any(not self._valid_card(card) for card in cards):
            raise ValueError("invalid card list")
